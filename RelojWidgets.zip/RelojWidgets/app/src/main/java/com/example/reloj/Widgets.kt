package com.example.reloj

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.widget.RemoteViews

/** Base de los tres widgets: al tocarlos se abren las alarmas del sistema. */
abstract class BaseClockWidget(private val layoutRes: Int) : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val tap = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        for (id in ids) {
            val views = RemoteViews(context.packageName, layoutRes)
            views.setOnClickPendingIntent(R.id.root, tap)
            manager.updateAppWidget(id, views)
        }
    }
}

class DigitalWidget : BaseClockWidget(R.layout.widget_digital)
class AnalogWidget : BaseClockWidget(R.layout.widget_analog)
class WorldWidget : BaseClockWidget(R.layout.widget_world)
