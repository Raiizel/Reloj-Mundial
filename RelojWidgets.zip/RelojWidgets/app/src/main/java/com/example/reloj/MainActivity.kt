package com.example.reloj

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.provider.AlarmClock
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply { text = getString(R.string.app_name); textSize = 32f })
        root.addView(TextView(this).apply { text = getString(R.string.how_to); textSize = 16f; setPadding(0, pad / 2, 0, pad) })
        root.addView(Button(this).apply {
            text = getString(R.string.create_alarm)
            setOnClickListener { launch(Intent(AlarmClock.ACTION_SET_ALARM)) }
        })
        root.addView(Button(this).apply {
            text = getString(R.string.see_alarms)
            setOnClickListener { launch(Intent(AlarmClock.ACTION_SHOW_ALARMS)) }
        })
        setContentView(root)
    }

    private fun launch(intent: Intent) {
        try { startActivity(intent) }
        catch (e: ActivityNotFoundException) { Toast.makeText(this, R.string.no_clock_app, Toast.LENGTH_LONG).show() }
    }
}
