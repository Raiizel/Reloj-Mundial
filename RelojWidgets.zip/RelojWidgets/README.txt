RelojWidgets (Android, Kotlin)

1. Abre esta carpeta en Android Studio (File > Open) y espera a que termine la sincronización de Gradle.
2. Ejecuta la app en un teléfono o emulador (Android 10 o superior).
3. En la pantalla de inicio, mantén pulsado un espacio vacío > Widgets > Reloj.

Widgets incluidos: digital (2x2), analógico (2x2) y hora mundial (3x2).
Para cambiar las ciudades: app/src/main/res/layout/widget_world.xml (android:timeZone) y strings.xml.
Al tocar un widget se abren las alarmas del sistema.
